package com.socrata.model.soql;

/**
 * Logically, any objects deriving from this interface will be an expression for a where clause.
 */
public interface Expression {

}
