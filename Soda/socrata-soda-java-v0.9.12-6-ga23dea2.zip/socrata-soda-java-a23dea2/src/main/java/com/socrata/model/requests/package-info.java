/**
 * The model objects (nouns) used for defining SODA requests.These objects are mainly used internally
 * by the API to provide "retry" logic in the case of 202 retries..
 **/
package com.socrata.model.requests;